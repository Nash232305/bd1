create
    definer = weatherappuser@localhost procedure find_all_citys(IN p_city_id int)
BEGIN
	if(p_city_id <= 0) then	 
	-- Agregar Bloque transaccional
		select * from city order by city_code asc;
	else 
		select * from city where city_code = p_city_id;
	end if;

END;

