create
    definer = weatherappuser@localhost procedure create_forecast(IN p_city_code int, IN p_temperature int,
                                                                 IN p_date date, OUT p_new_forecast_id int)
BEGIN
	
	-- Agregar Bloque transaccional
    DECLARE zipF INT; -- Se declara la variable para almacenar el código postal

    -- Obtener el código postal para la ciudad
    SELECT zip_code INTO zipF FROM city WHERE city_code = p_city_code;
	START TRANSACTION;
    INSERT INTO forecast(city_code,zip_code,temperature_celsius,forecast_date) values (p_city_code,zipF,p_temperature,p_date);
    select last_insert_id() into p_new_forecast_id;
    commit;
END;

