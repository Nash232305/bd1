create
    definer = weatherappuser@localhost procedure find_forecasts_log(IN p_cantidad int)
BEGIN
	
    if(p_cantidad <= 0) then	 

		SELECT * 
		FROM forecast_log
		ORDER BY last_modified_on DESC, id DESC;
		
	else 
		SELECT * 
		FROM forecast_log
		ORDER BY last_modified_on DESC, id DESC
		LIMIT p_cantidad;
	end if;
	

END;

