create
    definer = weatherappuser@localhost procedure delete_city(IN p_city_id int)
BEGIN

	-- Agregar Bloque transaccional
    START TRANSACTION;
    DELETE FROM city WHERE city_code = p_city_id;
    commit;


END;

