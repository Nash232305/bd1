create
    definer = weatherappuser@localhost procedure create_state(IN p_state_name varchar(100), IN p_country_code int,
                                                              OUT p_new_state_id int)
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    INSERT INTO state(state_name,country_code) values (p_state_name,p_country_code);
    select last_insert_id() into p_new_state_id;
    commit;
END;

