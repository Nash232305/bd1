create
    definer = weatherappuser@localhost procedure create_city(IN p_city_name varchar(100), IN p_zip_code int,
                                                             IN p_state_code int, OUT p_new_city_id int)
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    INSERT INTO city(city_name,zip_code,state_code) values (p_city_name,p_zip_code,p_state_code);
    select last_insert_id() into p_new_city_id;
    commit;
END;

