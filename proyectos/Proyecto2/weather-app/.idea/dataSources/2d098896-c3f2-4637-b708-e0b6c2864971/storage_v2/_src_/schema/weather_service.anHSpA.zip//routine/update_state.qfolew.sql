create
    definer = weatherappuser@localhost procedure update_state(IN p_state_id int, IN p_state_name varchar(100), IN p_country_code int)
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    update state set state_name = p_state_name, country_code=p_country_code where p_state_id = state_code;
    commit;
END;

