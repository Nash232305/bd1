create
    definer = weatherappuser@localhost procedure create_country(IN p_country_name varchar(100), OUT p_new_country_id int)
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    INSERT INTO country(country_name) values (p_country_name);
    select last_insert_id() into p_new_country_id;
    COMMIT;
END;

