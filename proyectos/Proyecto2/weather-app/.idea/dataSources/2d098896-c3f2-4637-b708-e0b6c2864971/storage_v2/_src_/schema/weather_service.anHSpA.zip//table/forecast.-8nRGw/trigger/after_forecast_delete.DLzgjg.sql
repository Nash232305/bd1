create definer = weatherappuser@localhost trigger after_forecast_delete
    after delete
    on forecast
    for each row
BEGIN
    INSERT INTO forecast_log (last_modified_on, entry_text, forecast_code)
    VALUES (CURDATE(), 'Forecast deleted', OLD.forecast_code);
END;

