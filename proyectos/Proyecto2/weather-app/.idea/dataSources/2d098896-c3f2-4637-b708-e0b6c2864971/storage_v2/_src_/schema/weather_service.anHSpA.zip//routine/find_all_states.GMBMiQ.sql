create
    definer = weatherappuser@localhost procedure find_all_states(IN p_state_id int)
BEGIN
	if(p_state_id <= 0) then	 
	-- Agregar Bloque transaccional
		select * from state order by state_code asc;
	else 
		select * from state where state_code = p_state_id;
	end if;

END;

