create
    definer = weatherappuser@localhost procedure find_all_countries(IN p_country_id int)
BEGIN
	if(p_country_id <= 0) then	 
	-- Agregar Bloque transaccional
		select country_code,country_name from country order by country_code asc;
	else 
		select * from country where country_code = p_country_id;
	end if;

END;

