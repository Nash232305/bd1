create
    definer = weatherappuser@localhost procedure update_forecast(IN p_forecast_id int, IN p_city_code int,
                                                                 IN p_temperature int, IN p_date date)
BEGIN
	-- Agregar Bloque transaccional ,,
    DECLARE zipF INT; -- Se declara la variable para almacenar el código postal

    -- Obtener el código postal para la ciudad
    START TRANSACTION;
    SELECT zip_code INTO zipF FROM city WHERE city_code = p_city_code;
    update forecast set city_code = p_city_code, temperature_celsius=p_temperature,forecast_date = p_date,zip_code = zipF where p_forecast_id = forecast_code;
    commit;
END;

