create
    definer = weatherappuser@localhost procedure find_all_forecasts_zip(IN p_zip int)
BEGIN
	if(p_zip <= 0) then	 
	-- Agregar Bloque transaccional
		select * from forecast order by zip_code asc;
	else 
		select * from forecast where zip_code = p_zip;
	end if;

END;

