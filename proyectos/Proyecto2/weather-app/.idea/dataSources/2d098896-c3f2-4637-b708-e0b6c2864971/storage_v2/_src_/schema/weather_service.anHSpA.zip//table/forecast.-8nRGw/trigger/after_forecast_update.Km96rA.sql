create definer = weatherappuser@localhost trigger after_forecast_update
    after update
    on forecast
    for each row
BEGIN
    INSERT INTO forecast_log (last_modified_on, entry_text, forecast_code)
    VALUES (CURDATE(), CONCAT('Update. Old temperature ', OLD.temperature_celsius, '. New value ', NEW.temperature_celsius), NEW.forecast_code);
END;

