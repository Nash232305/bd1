create
    definer = weatherappuser@localhost procedure delete_country(IN p_country_id int)
BEGIN

	-- Agregar Bloque transaccional
    START TRANSACTION;
    DELETE FROM country WHERE country_code = p_country_id;
    commit;


END;

