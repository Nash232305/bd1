create
    definer = weatherappuser@localhost procedure update_country(IN p_country_id int, IN p_country_name varchar(100))
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    update country set country_name = p_country_name where p_country_id = country_code;
    commit;
END;

