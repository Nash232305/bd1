create
    definer = weatherappuser@localhost procedure find_all_forecasts(IN p_forecast_id int)
BEGIN
	if(p_forecast_id <= 0) then	 
	-- Agregar Bloque transaccional
		select * from forecast order by forecast_code asc;
	else 
		select * from forecast where forecast_code = p_forecast_id;
	end if;

END;

