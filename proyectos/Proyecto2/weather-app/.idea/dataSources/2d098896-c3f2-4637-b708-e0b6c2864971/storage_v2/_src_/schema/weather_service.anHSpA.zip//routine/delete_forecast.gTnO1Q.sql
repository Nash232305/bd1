create
    definer = weatherappuser@localhost procedure delete_forecast(IN p_forecast_id int)
BEGIN

	-- Agregar Bloque transaccional
    START TRANSACTION;
    DELETE FROM forecast WHERE forecast_code = p_forecast_id;
    commit;


END;

