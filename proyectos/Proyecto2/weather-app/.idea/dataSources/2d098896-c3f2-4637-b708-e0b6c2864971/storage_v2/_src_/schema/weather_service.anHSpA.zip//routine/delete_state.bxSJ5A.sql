create
    definer = weatherappuser@localhost procedure delete_state(IN p_state_id int)
BEGIN

	-- Agregar Bloque transaccional
    START TRANSACTION;
    DELETE FROM state WHERE state_code = p_state_id;
    commit;


END;

