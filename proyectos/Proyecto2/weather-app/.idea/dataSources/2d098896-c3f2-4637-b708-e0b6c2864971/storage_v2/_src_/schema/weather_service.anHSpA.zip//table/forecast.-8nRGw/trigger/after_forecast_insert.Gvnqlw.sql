create definer = weatherappuser@localhost trigger after_forecast_insert
    after insert
    on forecast
    for each row
BEGIN
    INSERT INTO forecast_log (last_modified_on, entry_text, forecast_code)
    VALUES (CURDATE(), CONCAT('New forecast for city: ', (SELECT city_name FROM city WHERE city_code = NEW.city_code)), NEW.forecast_code);
END;

