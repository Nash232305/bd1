create
    definer = weatherappuser@localhost procedure find_all_forecasts_date(IN p_date date)
BEGIN
	if(p_date <=> null) then	 
	-- Agregar Bloque transaccional
		select * from forecast order by forecast_date asc;
	else 
		select * from forecast where forecast_date = p_date;
	end if;

END;

