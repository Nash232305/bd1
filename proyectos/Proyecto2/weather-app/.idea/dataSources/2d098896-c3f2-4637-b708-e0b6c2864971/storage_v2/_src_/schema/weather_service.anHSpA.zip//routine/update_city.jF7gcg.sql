create
    definer = weatherappuser@localhost procedure update_city(IN p_city_id int, IN p_city_name varchar(100),
                                                             IN p_zip_code int, IN p_state_code int)
BEGIN
	-- Agregar Bloque transaccional
    START TRANSACTION;
    update city set city_name = p_city_name, state_code=p_state_code, zip_code = p_zip_code where p_city_id = city_code;
    commit;
END;

